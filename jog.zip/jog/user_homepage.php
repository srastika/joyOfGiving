<?php
// require_once 'srastika_home.php'; 
// session_start();
 
// // Check if the user is logged in, if not then redirect him to login page
// if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
//     header("location: srastika_home.php");
//     exit;
// }
?>


<!DOCTYPE html>
<html>
    <head>
        <title>User homepage</title>
        <meta name="viewport" content="width=device-width,initial-scale=1"/>
        <link rel="stylesheet" href="style.css">

        
 
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

    <style>
        h2 {
        font-size: 3rem;
        letter-spacing: 2px;
        line-height: 1.5em;
        font-family: cursive;
        }
    </style>
    

    </head>
    <body align="center">


            

        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container-fluid">
              <div class="navbar-header">
                <a class="navbar-brand" href="index.php"><span class="glyphicon glyphicon-home"></span>HOME</a>
              </div>
            
              <div class="nav navbar-nav navbar-right">
                    <a class="navbar-brand" href="srastika_donationform.html">Donation</a>
                    <a class="navbar-brand" href="celebration.html">Celebration</a>
                        
                </div>
                
              </nav>
            </div>
          </nav>
            
        




            <div class="container">
                    <div class="center">
                        <div class="heart">
                            <p id="text"><b>Charity sees the need, not the cause!!</b> </p>
                        </div>
                    </div>
                
                </div>
                <br/><br/><br/>
                <img id="i1" src="PhoenixMarketcity_JoyOfGivingWeek_30Sept_8Oct2012.jpg" alt="image">
            <div class="row">
                <div class="column">
                    <br/><br/><br/><br/><br/><br/>
                    <h3 align="center">Your Donation</h3>
                            <dl>
                                <dt>1. 12 August 2018</dt>
                                <dd>- Miracle foundation</dd>
                                <dd>- 100 Books</dd>
                            </dl>
                            <dl>
                                    <dt>2. 4 January 2019</dt>
                                    <dd>- Sri Ram foundation</dd>
                                    <dd>- Clothes</dd>
                            </dl>
                </div>
                <div class="column">
                </div>
                <div class="column">
                    <br/><br/><br/><br/><br/><br/>
                    <h3 align="center">Celebration</h3>
                            <dl>
                                <dt>1. 30 June 2018</dt>
                                <dd>- Sri Ram foundation</dd>
                                <dd>- Birthday Celebration</dd>
                            </dl>
                </div>
            </div>
            
                <section align="center">
                <br/><br/><br/><br/><br/><br/>
        <h2><b>Share things Share happiness</b></h2>
        <br style="line-height: 100;">
        <p class="cls1">
            The small things you give and the little time you spend with them makes them feel happier.
            Their hunger for love is much more difficult to remove than hunger for bread.
        </p><br/>
        <h2><b>Why donate?</b></h2>
        <p class="cls1">
            Keep your unwanted belongings out of landfill by giving them
            a new life and getting them in hands of someone who really need them.
        </p>
        <br/>
        <h2><b>Inspire your nearest and dearest to donate!!</b></h2>
    </section>
    </body>
</html>