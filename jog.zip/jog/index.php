<?php
// session_start();
// if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
//   header("location: user_homepage.php");
//   exit;
// }
require_once "config.php";
if($_SERVER['REQUEST_METHOD']=='POST'){

$userid=trim($_POST['userid']);
$password=trim($_POST['password']);
if(!empty($userid)&&!empty($password)){
  //$password=$password,PASSWORD_DEFAULT);
  $sql_u = "SELECT * FROM `donater` WHERE userid='$userid'";
  $res_u = mysqli_query($conn, $sql_u);
  $count=mysqli_num_rows($res_u);

 
  if($count==0){
    echo "<script>alert('invalid user') </script>";
   }
  else{
$sql_e = "SELECT id,password FROM `donater` WHERE userid='$userid'";

$res_e = mysqli_query($conn, $sql_e);
$row = mysqli_fetch_assoc($res_e);
$id=trim($row['id']);
echo "<script>alert('$row[password]') </script>";
echo "<script>alert('$password') </script>";
$hash=trim($row['password']);
$salt="hello";
$userpass=crypt($password,$salt);
echo "<script>alert('$hash') </script>";
echo "<script>alert('$userpass') </script>";  
if($hash==$userpass){
  session_start();
                            
  // Store data in session variables
  $_SESSION["loggedin"] = true;
  $_SESSION["id"] = $id;
  $_SESSION["userid"] = $userid;
  header("location: user_homepage.php");
}
else{
  echo "<script> alert('invalid password') </script>";
}
}

}
}
?>


<html>
<head>
  <title>home page</title>
  <meta charset="utf-8">
  <link href="srastika_homeCSS.css" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"><span class="glyphicon glyphicon-home"></span>HOME</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="OrgList.html">NGO's list</a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span>Register <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="USER_REG.php">Donater</a></li>
              <li><a href="org_form1.php">NGO</a></li>
              
            </ul>
            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-log-in"></span>Login <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="#" onclick="on()">user</a>
                    <li><a href="#" onclick="on1()">NGO</a>

                  
                  </li>
                  
                </ul>
    </ul>
  </div>
</nav>
  
<div class="box">
 
    <img src="PhoenixMarketcity_JoyOfGivingWeek_30Sept_8Oct2012.jpg" id="img1"></img>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
  <div class="star"></div>
 <p id="quote">WHERE EVERY BIT HELPS</p>
</div>
<div >
    <div class="content">
        <p class="question"> what do we do?</p>
        <p class="answer"> want to donate things to orphangae or want to celebrate your special occcation with them??...here come we to make this happen</p>
        <p class="question"> how you can be part of this?</p>
        <p class="answer"> do register to donate or to reserve time slot for celebration or to make your NGO accept donations</p>
        <p class="question"> How do we operate?</p>
        <p class="answer"> For donation:once the donater submits the list of item he/she want to donate.We do a door step pickup of items and give it to orphanage </p>
        <p class="question"> how you can be part of this?</p>
        <p class="answer"> do register to donate or to reserve time slot </p>
        <p class="question"> what can you donate?</p>
        <p class="answer"> you can donate things such as clothes,shoes,staionaries,furnitures etc</p>

<p>
  ********************************************************
</p>
<p class="question"> what do people say?</p>

 
         <div id="bigYellowCircle"></div>
           <div id="blueSquare"></div>
          <div id="green"></div>
          <div id="red"></div>
         
            <section class="opinion">

              <div class="cards1"">
              
              <div class="image">
              
              <img src="avatar.jpg" class="customer">
              
              <div class="title">
              
              <h3>Mr.XXX</h3>
              
              </div>
              
              <div class="des">
             
                <p>it was a Great experiance celebrating my birthday at miraclefoundation</p>
                <P></P>
              </div>
              
              </div>
              
              </div>
              
              
              
              <div class="cards1">
              
              <div class="image">
              
              <img src="images.png"class="customer">
              
              <div class="title">
              
              
                <h3>xyz</h3>
              </div>
              
              <div class="des">
              
              
              
              
              <p>timely pickup and Great website to donat</p>
              <p>it was a Great experiance</p>
              </div>
              
              </div>
              
              </div>
              
              
              
              <div class="cards1">
              
              <div class="image">
              
              <img src="images1.png"class="customer"id="card3">
              
              <div class="title">
              
              <h3>abc</h3>
              
              </div>
              
              <div class="des">
              
                <p>timely pickup and Great website to donat</p>
                <p>it was a Great experiance</p>
                <p>it was a Great experiance</p>

              
              </div>
              
              </div>
              
              </div>
              
               
      
    </div>

</div>
</div>
<div class="add">
<address>
  <br>
  <br>
  <br>
  <span class="glyphicon glyphicon-earphone"></span>  contact No: 890 999 8909<br>

<span class="glyphicon glyphicon-envelope"></span> email-id:example@mdkk.com <br>
</address>
</div>
<div id="overlay"">
    <div id="text">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>"  class="form-container" method="POST">
          <h1>Login</h1>
      
          <label for="Username"><b>Userid</b></label>
          <input type="text" placeholder="Enter Username" name="userid" required>
      
          <label for="psw"><b>Password</b></label>
          <input type="password" placeholder="Enter Password" name="password" required>
      
          <button type="submit" class="btn">Login</button>
          <p type="submit" onclick="off()" ><span class="glyphicon glyphicon-home"style="color:green;position:relative;left:40%;font-size:30px"></span></p>
         
        </form>
      </div>
  </div>
  <div id="overlay1"">
    <div id="text">
        <form action="org_regp.php" class="form-container" method="POST">
          <h1>Login</h1>
      
          <label for="Username"><b>Username</b></label>
          <input type="text" placeholder="Enter NGO's name" name="nname" required>
      
          <label for="psw"><b>Password</b></label>
          <input type="password" placeholder="Enter Password" name="psw" required>
      
          <button type="submit" class="btn">Login</button>
          <p type="submit" onclick="off1()" ><span class="glyphicon glyphicon-home"style="color:green;position:relative;left:40%;font-size:30px"></span></p>
         
        </form>
      </div>
  </div>
<script>
 function on() {
  
  document.getElementById("overlay").style.display = "block";
}

function off() {
  document.getElementById("overlay").style.display = "none";
}
function on1() {

  document.getElementById("overlay1").style.display = "block";
}

function off1() {
  document.getElementById("overlay1").style.display = "none";
}
</script>
</body>
</html>