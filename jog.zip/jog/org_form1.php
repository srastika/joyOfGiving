
<?php
 
require_once "config.php";
$phone = $email = $address =$about= $time ="";
if($_SERVER["REQUEST_METHOD"]=='POST'){
    $name=trim($_POST['name']);
    $password1=trim($_POST['password']);
    $password2=trim($_POST['cp']);
    $phone=trim($_POST['phone']);
    $email=trim($_POST['email']);
    $address=trim($_POST["address"]);
    $about=trim($_POST['about']);
    $time = trim($_POST["time"]);
   
    $salt = "shreya";
    $password=crypt($password1,$salt);
     // Creates a password hash
 
    
     $sql_u = "SELECT * FROM `ngo` WHERE name='$name'";
    $res_u = mysqli_query($conn, $sql_u);
     $sql_e = "SELECT * FROM `ngo` WHERE email='$email'";
     $res_e = mysqli_query($conn, $sql_e);
    if (mysqli_num_rows($res_u) > 0) {
       
        echo "<script>alert('Sorry organisation name already taken') </script>";	
      }
   else if(mysqli_num_rows($res_e) > 0){
      $email_err="email id already exists";
      echo "<script>alert('Sorry email id already taken') </script>";
      	  
    }
    else if(strlen($password1)<6){
        echo "<script>alert('password should be atleast 6 character long') </script>"; 
    }
    else if($password1!=$password2){
        echo "<script>alert('password and confirm password do not match') </script>";
    }
    else{
   
   //$sql = "INSERT INTO `ngo` (`name`,`password`,`phone`,`email`,`address`,`about`,`time`) VALUES ('$name','$password',$phone','$email','$address','$about','$time')";
   $sql = "INSERT INTO `ngo` (`name`,`password`,`email`,`address`,`phone`,`about`,`time`) VALUES ('$name','$password','$email','$address','$phone','$about','$time')"; 
if ($conn->query($sql) === TRUE) {
echo"new record created"; 
header('Location: index.php');
exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

}
}
?> 



<!DOCTYPE html>
<html>
    <head>
        <title>org registration</title>
        <meta name="viewport" content="width=device-width,initial-scale=1"/>


        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>



        <style>
            body {
                background-image: url("Screenshot_20191013-171620~2.png");
                background-repeat: no-repeat;
                background-size: cover;
            }
            input {
                padding: 6px;
                font-size: 14px;
                margin: 5px;
            }
            label {
                width: 240px;
                text-align: right; 
                margin-right: 0.8em;
            }
            textarea {
                padding: 6px;
                font-size: 14px;
                display: inline-block;
            }

            #bu2{
                font-size: 20px;
                margin-top:15px; 
                position: relative;
                left:55%;
                
                font-family:sans-serif;
                height:60px ;

                border-radius: 50%;

                background: black;
                color: skyblue;
            }
            #bu2:hover{
                color: pink;
                }
            #bu1{
                font-size: 20px;
                margin-top:15px; 
                position: relative;
                
                
                font-family:sans-serif;
                height:60px ;

                border-radius: 50%;

                background: black;
                color: skyblue;
            }
            #bu1:hover{
                color: pink;  
            }    

        </style>
        <script>
        function fn1()
        {
         if(document.getElementById("pword1").value!=  document.getElementById("pword2").value)
         {
             alert("Password does not match");
         }
        }
        </script>
    </head>
    <body>


        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container-fluid">
              <div class="navbar-header">
                <a class="navbar-brand" href="index.php"><span class="glyphicon glyphicon-home"></span>HOME</a>
              </div>
              </nav>
            </div>
          </nav>



        <br/><br/><br/>
       
        <!-- <form onsubmit="fn1()" action="org_regp.php" method="POST">
                <table align="center">
                    <tr> 
                        <td><label>Name:</label></td>
                        <td><input type="text" name="name" size="30" /></td>
                    </tr>
                    <tr>
                        <td><label>Password:</label></td>
                        <td><input type="password" name="password" id="pword1" size="20"/></td>
                    </tr>
                    <tr>
                            <td><label>Confirm Password:</label></td>
                            <td><input type="password" id="pword2" size="20" name="cp"value=></td>
                        </tr>
                    <tr>
                        <td></td>
                        <td><label><input type="submit" id="bu2" value="Submit"></label></td>
                    </tr>
                    </table>
        </form> -->
                   
                    
        <form onsubmit="fn1()" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                    <table align="center">
                    <tr> 
                        <td><label>Name:</label></td>
                        <td><input type="text" name="name" size="30" /></td>
                    </tr>
                    <tr>
                        <td><label>Password:</label></td>
                        <td><input type="password" name="password" id="pword1" size="20"/></td>
                    </tr>
                    <tr>
                            <td><label>Confirm Password:</label></td>
                            <td><input type="password" id="pword2" size="20" name="cp"value="<?php echo isset($_POST['password']) ? $_POST['password'] : '' ?>"></td>
                        </tr>
                    <tr>
                    <tr>  <h2 align="center">Register your Organisation</h2>
                        <td><label>Contact no:</label></td>
                        <td><input type="phone" name="phone" size="20" maxlength="10" /></td>
                    </tr>
                    <tr>
                        <td><label>Email-id:</label></td>
                        <td><input type="email" name="email" size="30" /></td>
                    </tr>
                    <tr>
                        <td><label>Address:</label></td>
                        <td><textarea name="address" rows="3" cols="30"></textarea></td>
                    </tr>
                    <tr>
                        <td><label>Visitors Timing</label></td>
                        <td><input type="time" name="timing"/>
                    </tr>
                    <tr>
                        <td><label>About:</label></td>
                        <td><textarea name="about" rows="4" cols="30"></textarea></td>
                    </tr>
                    <tr>
                           <td><label><input type="submit" id="bu2" value="Submit"/></label></td> 
                            <td><label><input type="reset" id="bu1" value="Reset" /></label></td>
                    </tr>
                </table>
        </form>


    </body>
</html>