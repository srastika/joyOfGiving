<?php 
require_once "config.php";
$firstname = $lastname = $middlename = $password = $userid = "";
$occupation = $email = $address = $age = $phone1 = $phone2= "";
$country =$city =$confirm_password="";
if($_SERVER["REQUEST_METHOD"]=='POST'){
    $userid=trim($_POST['userid']);
    $firstname=trim($_POST['firstname']);
    $lastname=trim($_POST['firstname']);
    $middlename=trim($_POST['firstname']);
    $password1=trim($_POST["password"]);
    $password2=trim($_POST['confirm_password']);
    $phone2 = trim($_POST["phone2"]);
    $phone1 = trim($_POST["phone2"]);
    $email = trim($_POST["email"]);
    $age = trim($_POST["age"]);
    $occupation = trim($_POST["occupation"]);
    $address = $_POST["age"];
    $city = trim($_POST["city"]);
    $age = trim($_POST["age"]);
    $country = trim($_POST["country"]);
   // $password=password_hash($password, PASSWORD_DEFAULT);
    $salt = "hello";
    $password=crypt($password1,$salt);
     // Creates a password hash
    //$use = mysql_real_escape_string($username); // escape string before passing it to query.
    
    $sql_u = "SELECT * FROM `donater` WHERE userid='$userid'";
    $res_u = mysqli_query($conn, $sql_u);
    $sql_e = "SELECT * FROM `donater` WHERE email='$email'";
    $res_e = mysqli_query($conn, $sql_e);
    if (mysqli_num_rows($res_u) > 0) {
       
        echo "<script>alert('Sorry username already taken') </script>";	
      }
    else if(mysqli_num_rows($res_e) > 0){
      $email_err="email id already exists";
      echo "<script>alert('Sorry email id already taken') </script>";
      	  
    }
    else if(strlen($password1)<6){
        echo "<script>alert('password should be atleast 6 character long') </script>"; 
    }
    else if($password1!=$password2){
        echo "<script>alert('password and confirm password do not match') </script>";
    }
    else{
    // Validate password
 
   //$sql = "insert into donater (userid) VALUES($userid)";
   $sql = "INSERT INTO `donater` (`firstname`,`userid`,`password`,`middlename`,`lastname`,`phone2`,`age`,`occupation`,`address`,`email`,
   `city`,`phone1`,`country`) VALUES ('$firstname','$userid','$password','$middlename','$lastname','$phone2','$age','$occupation','$address','$email','$city','$phone1','$country')";
    
if ($conn->query($sql) === TRUE) {
    
// Checking For Blank Fields..

// Check if the "Sender's Email" input field is filled out
$email=trim($_POST['email']);
// Sanitize E-mail Address
// $email =filter_var($email, FILTER_SANITIZE_EMAIL);
// // Validate E-mail Address
// $email= filter_var($email, FILTER_VALIDATE_EMAIL);
// if (!$email){
// echo "Invalid Sender's Email";
// }
$email2 ="srastikas2@gmail.com";
$email1="srastikashetty@gmail.com";    
$subject = "1st mail";
$message = "i wish reaches";
$headers = 'From:'. $email2 . "rn"; // Sender's Email
$headers .= 'Cc:'. $email2 . "rn"; // Carbon copy to Sender
// Message lines should not exceed 70 characters (PHP rule), so wrap it
$message = wordwrap($message, 70);
// Send Mail By PHP Mail Function
mail($email2, $subject, $message, $headers);



    header('Location: index.php');
exit;
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

}
}
?>


<html>
    <head>
	<link rel="stylesheet" href="backgroundanimation.css">
	<meta name="viewport" content="width=device-width,initial-scale=1">	

      	 <style>
		
		input,textarea
		{
			text-align:center;
		}
		.form_error{

        }
	      
        </style>
	
    </head>
 
<body style="background-color:lightgreen;">
<div class="navbar-header">
<a class="navbar-brand" href="index.html"><span class="glyphicon glyphicon-home"></span>HOME</a>
</div>
<ul class="bubbles">
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
        <li></li>
    </ul>
<div class="bg"></div>
<form name="User_Reg" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" id="form">
<table>
<tr>
<td>
<h1>Enter your details to Register</h1>
</td>
</tr>

<tr>
<td>
<h3>Personal Information</h3>
</td>
</tr>

<tr>
<td>First Name:</td>
<td>
<input type="text" id="Fname" name="firstname" value="<?php echo isset($_POST['firstname']) ? $_POST['firstname'] : '' ?>"><br>
</td>
</tr>

<tr>
<td>Middle Name:</td>
<td>
<input type="text" id="Mname" name="middlename"value="<?php echo isset($_POST['middlename']) ? $_POST['middlename'] : '' ?>"><br>
</td>
</tr>

<tr>
<td>Last Name:</td>
<td>
<input type="text" id="Lname" name="lastname" value="<?php echo isset($_POST['lastname']) ? $_POST['lastname'] : '' ?>"><br>
</td>
</tr>

<tr>
<td>Age:</td>
<td>
<input type="number" name="age"value="<?php echo isset($_POST['age']) ? $_POST['age'] : '' ?>"><br>
</td>
</tr>

<!-- <tr>
<td>Gender:</td>
<td>
<input type="radio" name="gender" value="male" checked>Male<br>
<input type="radio" name="gender" value="female">Female<br>
<input type="radio" namnder" value="other">Other<br>
</td>
</tr> -->

<tr>
<td>Occupation:</td>
<td>
<select name="occupation" required>
<option>Business</option>
<option>Govt Job</option>
<option>Private Job</option>
<option>Student</option>
</select>
</td>
</tr>

<tr>
<td>
</br>
<h3>Contact Details</h3>
</td>
</tr>

<tr>
<td>Contact_number:</td>
<td>
<input type="phone" name="phone1" maxlength="10" required value="<?php echo isset($_POST['phone1']) ? $_POST['phone1'] : '' ?>"><br>
</td>
</tr>

<tr>
<td>Optional_Contact_number:</td>
<td>
<input type="phone" name="phone2" maxlength="10" value="<?php echo isset($_POST['phone2']) ? $_POST['phone2'] : '' ?>"><br>
</td>
</tr>

<tr>
<td>E-Mail:</td>
<td>
<input type="email" name="email"value="<?php echo isset($_POST['email']) ? $_POST['email'] : '' ?>"><br>
</td>
</tr>

<tr>
<td>Country:</td>
<td>
<input type="text" name="country" value="India" readonly><br>
</td>
</tr>

<tr>
<td>City:</td>
<td>
<select name="city" required value="<?php echo isset($_POST['city']) ? $_POST['city'] : '' ?>"><br>
<option value="Mumbai">Mumbai</option>
<option value="Pune">Pune</option>
<option value="Kolhapur">Kolhapur</option>
<option value="Bangalore">Bangalore</option>
<option value="Mysore">Mysore</option>
<option value="Ooty">Ooty</option>
</select><br>
</td>
</tr>

<tr>
<td>Address:</td>
<td>
<input type="text" id="add" name="address"value="<?php echo isset($_POST['address']) ? $_POST['address'] : '' ?>" required><br>
</td>
</tr>

<tr>
<td>
</br>
<h3>Create your UserID and Password</h3>
</td>
</tr>

<tr>
<td >UserID:</td>
<td>
   
<input type="text" id="UserID" name="userid" value="<?php echo isset($_POST['userid']) ? $_POST['userid'] : '' ?>" required><br>
</td>
</tr>

<tr>
<td>Password:</td>
<td>
<input type="password" id="password" maxlength="8" name="password" value="<?php echo isset($_POST['password']) ? $_POST['password'] : '' ?>" required><br>
</td>
</tr>

<tr>
<td> Confirm Password:</td>
<td>
<input type="password" id="password1" maxlength="8" name="confirm_password" value="<?php echo isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '' ?>" required><br>
</td>
</tr>

<tr>
<td>
 <button type="submit" class="btn" >submit</button>

</td>
</tr>

<tr>
<td>
 <input type="reset" class="btn" onclick="formreset()">
<p type="submit" onclick="off()" ><span class="glyphicon glyphicon-home"style="color:green;position:relative;left:40%;font-size:30px"></span></p>
</td>
</tr>
</table>
</form>
</body>
</html>


<!-- 
//PHP PART
require_once "config.php";
$firstname = $lastname = $middlename = $password = $userid = "";
$occupation = $email = $address = $age = $phone1 = $phone2= "";
$country ="";
$userid_err = $password_err = $confirm_password_err = "";
$firstname_err = $lastmast_err = $middlename_err = "";
$occupation_err = $email_err = $address_err = $age_err = $phone1_err = $phone2_err= "";
$country_err ="";
if($_SERVER["REQUEST_METHOD"] == "POST")
{
 
  // Validate username
  if(empty(trim($_POST["userid"]))){
      $userid_err = "Please enter a username.";
  } else{
      // Prepare a select statement
      $sql = "SELECT id FROM donater WHERE userid = ?";
     
      if($stmt = mysqli_prepare($link, $sql)){
          // Bind variables to the prepared statement as parameters
          mysqli_stmt_bind_param($stmt, "s", $param_userid);
          
          // Set parameters
          $param_userid = trim($_POST["userid"]);
          
          // Attempt to execute the prepared statement
          if(mysqli_stmt_execute($stmt)){
              /* store result */
              mysqli_stmt_store_result($stmt);
              
              if(mysqli_stmt_num_rows($stmt) == 1){
                  $userid_err = "This userid is already taken.";
              } else{
                  $userid = trim($_POST["userid"]);
              }
              mysqli_stmt_close($stmt); 
          } else{
              echo "Oops! Something went wrong. Please try again later.";
          }
      }
       
      // Close statement
    
  //}
  
 
   // Validate username
   if(empty(trim($_POST["firstname"]))){
    $firstname_err = "Please enter a firstname";
} else{
  $firstname = trim($_POST["firstname"]);
    }

  //lastname
  if(empty(trim($_POST["lastname"]))){
    $lastname_err = "Please enter a firstname";
} else{
  $lastmast = trim($_POST["lastname"]);
    }    
     
    if(empty(trim($_POST["middlename"]))){
      $middlename_err = "Please enter a firstname";
  } else{
    $middlename = trim($_POST["lastname"]);
      }


      if(empty(trim($_POST["phone1"]))){
        $phone1_err = "Please enter a firstname";
    } else{
      $phone1 = trim($_POST["lastname"]);
        }                
$phone2 = trim($_POST["phone2"]);
$email = trim($_POST["email"]);
$age = trim($_POST["age"]);
$occupation = trim($_POST["occupation"]);
$address = $_POST["age"];
$city = trim($_POST["city"]);
$age = trim($_POST["age"]);
        



} // Validate password
  if(empty(trim($_POST["password"]))){
      $password_err = "Please enter a password.";     
  } elseif(strlen(trim($_POST["password"])) < 6){
      $password_err = "Password must have atleast 6 characters.";
  } else{
      $password = trim($_POST["password"]);
  }
  
  // Validate confirm password
  if(empty(trim($_POST["confirm_password"]))){
      $confirm_password_err = "Please confirm password.";     
  } else{
      $confirm_password = trim($_POST["confirm_password"]);
      if(empty($password_err) && ($password != $confirm_password)){
          $confirm_password_err = "Password did not match.";
      }
  }
  
  // Check input errors before inserting in database
  if(empty($userid_err) && empty($password_err) && empty($confirm_password_err)&& empty($firstname_err)&&empty($lastmast_err) && empty($middlename_err)&& empty($phone1)){
      
      // Prepare an insert statement
      $sql = "INSERT INTO donater (firstname,middlename,lastname, password,age,occupation,phone1,phone2,email,country,city,address,userid) VALUES (?, ?,?,?,?,?,?,?,?,?,?,?,?)";
       
      if($stmt = mysqli_prepare($link, $sql)){
          // Bind variables to the prepared statement as parameters
          mysqli_stmt_bind_param($stmt, "ssssisiisssss", $param_firstname,$param_middlename,$param_lastname,$param_password,$param_age,$param_occupation,$param_phone1,$param_phone2,$param_email,$param_country,$param_city,$param_address,$param_userid);
          
          // Set parameters
          //$param_username = $username;
          $param_firstname=$firstname;
          $param_middlename=$middlename;
          $param_lastname =$param_lastname;
          $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
          $param_age =$age;
          $param_occupation=$occupation;
          $param_phone1=$phone1;
          $param_phone2=$phone2;
          $param_email=$email;
          $param_country=$country;
          $param_city=$city;
          $param_address=$address;
          $param_userid=$param_userid;
          
          // Attempt to execute the prepared statement
          if(mysqli_stmt_execute($stmt)){
              // Redirect to login page
              header("location: srastika_home.php");
              mysqli_stmt_close($stmt);
          } else{
              echo "Something went wrong. Please try again later.";
          }
      }
       
      // Close statement
     
  }
  
  // Close connection
  mysqli_close($link);
}
?> -->



