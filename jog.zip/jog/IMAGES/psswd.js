<script type="text/javascript">
	if(document.getElementById("password").value != document.getElementById("password1").value)
	alert("Passwords donot match!");
	</script>