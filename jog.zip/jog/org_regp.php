<?php 
session_start();
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
  header("location: ORG_PAGE.html");
  exit;
}
require_once "config.php";
if($_SERVER['REQUEST_METHOD']=='POST'){

$name=trim($_POST['nname']);
$password=trim($_POST['psw']);
if(!empty($name)&&!empty($password)){
  //$password=$password,PASSWORD_DEFAULT);
  $sql_u = "SELECT * FROM `ngo` WHERE name='$name'";
  $res_u = mysqli_query($conn, $sql_u);
  $count=mysqli_num_rows($res_u);

 
  if($count==0){
    header("index.php"); 
    echo "<script>alert('invalid user') </script>";
   }
  else{
$sql_e = "SELECT id,password FROM `ngo` WHERE name='$name'";

$res_e = mysqli_query($conn, $sql_e);
$row = mysqli_fetch_assoc($res_e);
$id=trim($row['id']);
echo "<script>alert('$row[password]') </script>";
echo "<script>alert('$password') </script>";
$hash=trim($row['password']);
$salt="shreya";
$userpass=crypt($password,$salt);
echo "<script>alert('$hash') </script>";
echo "<script>alert('$userpass') </script>";  
if($hash==$userpass){
  session_start();
                            
  // Store data in session variables
  $_SESSION["loggedin"] = true;
  $_SESSION["id"] = $id;
  $_SESSION["userid"] = $userid;
  header("location:ORG_PAGE.html");
}
else{
 header("index.php");  
  echo "<script> alert('invalid password') </script>";
}
}

}
}

?>