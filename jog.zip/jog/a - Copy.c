#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){

char** a =(char**)malloc(sizeof(char)*20);
for (int i = 0; i < 5; i++) {
         *(a + i) = malloc(20 * sizeof(char));
      }  
    *(a + 0) = "code";
      *(a + 1) = "anagram";
      *(a + 2) = "doec";
      *(a + 3) = "cdoe";
      *(a + 4) = "array";
for(int i=0;i<4;++i){
for(int j=i+1;j<4;++j){    
if(strlen(*(a+i))==strlen(*(a+j))){
    printf("yes\n");
    char* s=*(a+i);
    char* y=*(a+i);
    int sum1=  0;
    int sum2=0;
    for(int k=0;k<strlen(*(a+j));++k){
        sum1+=s[k]-'a';
        sum2+=y[k]-'a';
    }
    if(sum2==sum1){
        *(a+j)='\0';
    }
}
}
}
for(int i=0;i<4;++i){
printf("%s",*(a+i));
}

}